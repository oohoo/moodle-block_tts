//also rebuilds spans... this should be renamed.
wipeSpanData:function(){
if (typeof tts.config.spans.spanCollection !== 'undefined'){
	tts.config.spans.spanCollection
		.each(function(){
			$this = $(this);
			if (typeof $this.data('sound') !== 'undefined'){
				$this.data('sound').destruct();
				$this.removeData('sound');
			}
			$this
				.removeData('errors')
				.removeData('state')
				.removeData('file')
				.removeData('number')
				.removeData('dirty_mp3')
				.removeData('error_sound_loaded')
				.removeData('text_to_speak')
				.unbind();
			if (typeof tts.config.cache.enabled !== 'undefined' && tts.config.cache.enabled === true ){
				$this
					.removeData('key')
					.removeData('value')
					.removeData('stored');
			}
		});
	/*CACHE CODE - wipe out cache fields here.  Also reset global caching variables*/
	if(tts.config.spans.spanCollection.length > 0){
		tts.config.spans.spanCollection.each(function(n){
			$this = $(this);
			$this
				.data('errors',0)
				.data('state',tts.config.prefetch.NOT_PREFETCHED)
				.data('number',n)
				.data('dirty_mp3',false)
				.data('error_sound_loaded',false)
				.data('text_to_speak',$this.text().replace(/[^a-zA-Z 0-9]+/g,'').replace(/^\s+|\s+$/g,'').replace(/\s+/g,' '))
				.click( function( event ) {
					$this = $(this);
					if ($this.parents("a").length > 0){
							tts.spanController.pauseAll();
							return;
					}
					if(n == tts.config.spans.currentSpan){
						
						if(typeof $this.data('sound') !== 'undefined'){
							//check playstate and readystate
							if ($this.data('sound').readyState == 3){
								if($this.data('sound').playState == 1){
									tts.spanController.pauseAll();
								}
								else{
									tts.spanController.pauseAll();
									tts.spanController.playCurrentSpan();
								}
							}
						}
					}else{
						tts.spanController.skip(n - tts.config.spans.currentSpan);
					}
				});
			/*
			CACHE CODE - if there is caching in the browser(global), generate .data('key')
			Also use data('key') to set data('stored') by looking up if the key value exists.
			This will be used by other functions to prevent unnecessary server load.
			*/							
			if (typeof tts.config.cache.enabled !== 'undefined' && tts.config.cache.enabled === true ){
				$this.data('key',hashcalcMD4(tts.config.services.currentService + tts.config.services.currentVoice + $this.data('text_to_speak')));
				//check if stored.
				if (typeof $.storage.get($this.data('key')) !== 'undefined'){
					$this
						.data('stored',true)
						.data('value',$.storage.get($this.data('key')))
						.data('file',$this.data('value'))
						.data('state',3);
					tts.prefetcher.buildSound($this);
				}
				else{
					$this.data('stored',false);
				}
			}

		});
		$.extend(tts.config.spans,{
			currentSpan:0,
			previousSpan:-1,
			nextSpanToPlay:0,
			firstPlay:true,
			playingSpans:0,
			notWaitingToPlayCurrent:true,
			globalMute:false,
		});
		$.extend(tts.config.prefetch,{
			blockFatFetch:false,
			fatFetchInProgress:false,
			fatFetchAttempts:0,
			firstErrorPass:true,
			unfinishedSounds:[],
			errorSpans:[],
			alreadyReporting:false,
			blockDialogFetch:true
		});
		/*CACHE CODE - reset globals here*/
	}
	if(typeof tts.config.prefetch.MAX_REQUESTS !== 'undefined'){
		//start logging requests
		if(typeof tts.config.prefetch.currentRequests !== 'undefined'){
			delete tts.config.prefetch.currentRequests;
		}					
	}
	if (typeof tts.config.SM !== 'undefined' && typeof tts.config.SM.HAS_ONREADY !== 'undefined'){
		delete tts.config.SM;
	}
}
},

prefetcher:{

	fetchController: function(){

		if (tts.config.prefetch.blockFatFetch === false && typeof tts.config.prefetch.blockFatFetch !== 'undefined' && tts.config.prefetch.fatFetchInProgress === false){
			
			tts.config.prefetch.fatFetchInProgress = true;
			
			var datas = {
				"voice":tts.config.services.currentVoice,
				"service":tts.config.services.currentService,
				"course":tts.config.TTS.course,
				"data":[]
			};
			
			//collect all of the spans with status of 0.
			for (i=0;i<tts.config.spans.spanCollection.length;i++){
				var $span = tts.config.spans.spanCollection.eq(i);
				if ($span.data('state') == tts.config.prefetch.NOT_PREFETCHED){
					datas.data[i] = $span.data('text_to_speak');
				}
			}
			
			if (datas.data.length != 0){

				tts.config.prefetch.fatFetchAttempts += 1;
				$.ajax({
					asynch:false,
					cache:false,
					context:$span,
					data:datas,global:false,
					dataType:'json',
					beforeSend: function(x) {
						if(x && x.overrideMimeType) {
							x.overrideMimeType("application/j-son;charset=UTF-8");
						}
					},
					timeout:60000,
					type:"POST",
					url:tts.config.prefetch.FAT_FETCH_URL,
					error:function(){
						if (tts.config.prefetch.fatFetchAttempts <= tts.config.prefetch.maxFatFetchAttempts){
							tts.config.prefetch.fatFetchInProgress = false;
							tts.prefetch.fetchController();
						}
						else{
							//do not do this again
							tts.config.prefetch.blockFatFetch = true;
							tts.config.prefetch.blockDialogFetch = false;
							tts.config.prefetch.fatFetchInProgress = false;
							tts.prefetch.fetchController();
						}
					},
					success:function(result){
						if (typeof result === 'object'){
							$.each(result, function(j,val) {
								var keySpan = tts.config.spans.spanCollection.eq(j);
								if (!keySpan.data('sound')){
									keySpan.data('state',tts.config.prefetch.SERVER_HAS_MP3);
									keySpan.data('file',val.replace("\\",""));
									tts.prefetcher.buildSound(keySpan);
								}
							});
						}
						tts.config.prefetch.blockFatFetch = true;
						tts.config.prefetch.blockDialogFetch = false;
						tts.config.prefetch.fatFetchInProgress = false;
						tts.prefetch.fetchController();	
					}
				});//ajax end

			}
			
		}
		
		if(tts.config.prefetch.blockDialogFetch === false && typeof tts.config.prefetch.blockDialogFetch !== 'undefined'){
			tts.prefetcher.fetch(-1);
		}
		
	},

	reportErrors: function(){
		
		//prep things if necessary
		if(typeof tts.config.prefetch.firstErrorPass !== 'undefined' && tts.config.prefetch.firstErrorPass === true){
			if(typeof tts.config.prefetch.unfinishedSounds === 'undefined'){
				//instantiate
				$.extend(tts.config.prefetch,{
					unfinishedSounds:[]
				});
			}
			var unfinished = [];
			for (i=0;i<tts.config.spans.spanCollection.length;i++){
				var $span = tts.config.spans.spanCollection.eq(i);
				if ($span.data('state') < tts.config.prefetch.SPAN_HAS_LOADED_SOUND){
					unfinished.push = $span.data('number');
				}
			}
			$.extend(tts.config.prefetch,{
					unfinishedSounds:unfinished
				});
			tts.config.prefetch.firstErrorPass = false;
			setTimeout(tts.prefetcher.reportErrors,2000);
			return;
		}
		
		//traverse the unfinished sounds and update the array
		if(tts.config.prefetch.unfinishedSounds.length === 0){
			var unfinished = [];
			for (i=0;i<tts.config.prefetch.unfinishedSounds.length;i++){
				var n = tts.config.prefetch.unfinishedSounds[i];
				var $span = tts.config.spans.spanCollection.eq(n);
				if ($span.data('state') < tts.config.prefetch.SPAN_HAS_LOADED_SOUND){
					unfinished.push = $span.data('number');
				}
			}
			$.extend(tts.config.prefetch,{
				unfinishedSounds:unfinished
			});			
			if (unfinished.length === 0){
				if (tts.config.prefetch.errorSpans.length !== 0){
					//ajax call to report to server.
					var datas = {
						"errors":[],
						"thisURL":window.location.pathname
					};
					
					//collect all of the spans with status of 0.
					for (i=0;i<tts.config.prefetch.errorSpans.length;i++){
						var n = tts.config.prefetch.unfinishedSounds[i];
						var $span = tts.config.spans.spanCollection.eq(n);
						datas.errors[$span.data('file')] = $span.data('text_to_speak');
					}					
					
					};
					$.ajax({
						asynch:false,
						cache:false,
						data:datas,
						global:false,
						dataType:'json',
						beforeSend: function(x) {
							if(x && x.overrideMimeType) {
								x.overrideMimeType("application/j-son;charset=UTF-8");
							}
						},
						timeout:60000,
						type:"POST",
						url:tts.config.prefetch.ERROR_REPORT_URL,
						error:function(){
							//possibly do variable reset here?
						},
						success:function(){
						}
					});//ajax end					
				}
		}
		else {
			setTimeout(tts.prefetcher.reportErrors,2000);				
		}
	},
		
	buildSound: function(sel){
		if (soundManager.enabled){
			sel.
				data( 'sound', soundManager.createSound({
					id : 'sound' + sel.data('number'),
					url : sel.data('file'),
					span : sel, //for referencing the span if scrolling is on.  may also help for highlite.
					/**alteration**/
					onload: function(){
						if ( sel.data('sound').readyState == 2 ){
							//destroy the sound and build it again.
							sel.data('sound').destruct();
							sel.removeData('sound');					
							
							if (sel.data('dirty_mp3') === true){
								sel.data('file',tts.config.prefetch.ERROR_SOUND_URL);
								sel.data('error_sound_loaded',true);
								sel.data('state',tts.config.prefetch.SPAN_THREW_ERROR);
								tts.prefetcher.buildSound(sel);
								return;
							}
							//check if storing
							if(tts.config.cache.enabled === true){
								if (sel.data('stored') === true){
									$.storage.del(sel.data('key'));
								}
							}
							sel.data('dirty_mp3',true);
							var timestamp = new Date().getTime();
							sel.data('file',sel.data('file') + timestamp);
							tts.prefetcher.buildSound(sel);					
							

						}
						else{
							if(sel.data('error_sound_loaded')){
								//add to error report array
								tts.config.prefetch.errorSpans[sel.data('file')] = sel.data('text_to_speak');
								//may want to check typeof and set it up if it does not exist?
								//will also need to reset this and error spans in wipespans and possibly in json config
								if (tts.config.prefetch.alreadyReporting === false){
									tts.config.prefetch.alreadyReporting = true;
									tts.prefetcher.reportErrors();
								}//call error report array
								return;
							}
							else{
								sel.data('state',tts.config.prefetch.SPAN_HAS_LOADED_SOUND);
								if(tts.config.cache.enabled === true){
									if (sel.data('stored') === false){
										$.storage.set( sel.data('key'), sel.data('file'));
										sel.data('stored',true);
									}
								}					
							}
						}
					},
					/** end alteration **/
					onfinish: function(){
					}
				} ) );	
		}
		else{//build a queue			
		}
	},
}

//todo
/*
finish report.js
audit new variables to make sure they are created and destroyed and reset appropriately
implement the server side logic.
*/